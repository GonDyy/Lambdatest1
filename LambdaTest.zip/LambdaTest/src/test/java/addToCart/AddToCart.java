package addToCart;

import baseTest.BaseTest;
import org.testng.annotations.Test;

public class AddToCart extends BaseTest {
    @Test
    public void addToCartTest() {
        // 1. Hover over the "Mega Menu" and click on "Laptops & Notebooks"
        homePage.hoverMegaMenu();
        homePage.clickOnSubMenu("Laptops & Notebooks");

        // 2. Click on the "MacBook" product
        subMenuPage.clickOnProduct("MacBook");

        // 3. Click on the "Add to Cart" button
        subMenuPage.clickAddToCart();

        // 4. Verify that the success message is displayed
        String expectedMessage = "Success: You have added MacBook to your shopping cart!";
        String actualMessage = subMenuPage.getSuccessMessage();
        assert actualMessage.contains(expectedMessage) : "Expected message not found in actual message.";
    }
}
